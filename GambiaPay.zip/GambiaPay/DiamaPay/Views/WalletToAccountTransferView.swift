//
//  WalletToAccountTransferView.swift
//  DiamaPay
//
//  Created by Bits on 30/9/2025.
//


//
//  WalletToAccountTransferView.swift
//  DiamaPay
//
//  Created by Bits on 30/9/2025.
//

import SwiftUI

struct WalletToAccountTransferView: View {
    @Environment(\.presentationMode) var presentationMode
    
    // MARK: - State Variables
    @State private var linkedAccounts: [Account] = []
    @State private var selectedAccount: Account?
    @State private var accountName: String = ""
    @State private var amount: String = ""
    @State private var paymentDetails: String = ""
    
    @State private var isLoadingAccounts = false
    @State private var isVerifying = false
    @State private var isLoading = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var alertTitle = "Erreur"
    
    // Source of funds (balance only)
    @State private var currentBalance: String = ""
    
    // Transfer management
    @State private var calculatedFee: Double = 0.0
    @State private var totalAmountWithFee: Double = 0.0
    @State private var feeRuleIndex = ""
    @State private var nameEnquiryAuthCode: String = ""
    
    @State private var withdrawalFee: Double = 0.0
    @State private var isWithdrawalFeeEnabled: Bool = false
    @State private var isCalculatingWithdrawalFee = false
    @State private var withdrawalFeeError: String? = nil
    
    // Success dialog state
    @State private var showSuccessDialog = false
    @State private var transactionId = ""
    @State private var transactionDate = ""
    @State private var transactionReference = ""
    
    private let userDataManager = UserDataManager.shared
    private let defaultCurrency = "GNF"
    private let numericCurrency = "324"
    
    @State private var showConfirmationDialog = false
    
    var body: some View {
        ZStack {
            Color(UIColor.systemGroupedBackground)
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Header
                DiamaPayHeader()

                if isLoading {
                    Spacer()
                    VStack(spacing: 16) {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .blueH))
                            .scaleEffect(1.5)
                        
                        Text("Traitement en cours...")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.secondary)
                    }
                    Spacer()
                } else {
                    ScrollView {
                        VStack(spacing: 16) {
                            // Title Card
                            titleCard
                            
                            // Balance Display
                            balanceCard
                            
                            // Recipient Details Card
                            recipientDetailsCard
                            
                            // Amount Card
                            amountCard

                            // Reference Card
                            referenceCard
                            
                            // Submit Button
                            submitButton
                        }
                        .padding(.horizontal, 16)
                        .padding(.top, 20)
                    }
                }
            }
        }
        .navigationBarHidden(true)
        .alert(alertTitle, isPresented: $showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(alertMessage)
        }
        .sheet(isPresented: $showSuccessDialog) {
            AccountTransferSuccessView(
                transactionId: transactionId,
                transactionDate: transactionDate,
                amount: amount,
                accountName: accountName,
                accountNumber: selectedAccount?.accountNumber ?? "",
                bankName: selectedAccount?.bankName ?? "",
                senderName: userDataManager.getUserName(),
                senderWallet: userDataManager.getWalletNumber(),
                senderPhone: userDataManager.getPhoneNumber(),
                withdrawalFee: isWithdrawalFeeEnabled ? withdrawalFee : 0.0,
                fee: calculatedFee,
                total: totalAmountWithFee,
                currency: defaultCurrency,
                paymentDetails: paymentDetails,
                onClose: {
                    showSuccessDialog = false
                    presentationMode.wrappedValue.dismiss()
                }
            )
        }
        .overlay(confirmationDialogOverlay)
        .onAppear {
            fetchLinkedAccounts()
            fetchWalletBalance()
        }
    }
    

    private func formatAmount(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.locale = Locale(identifier: "fr_FR")
        return (formatter.string(from: NSNumber(value: amount)) ?? "0") + " " + defaultCurrency
    }
    
    
    private var confirmationDialogOverlay: some View {
        Group {
            if showConfirmationDialog {
                AccountTransferConfirmationDialog(
                    amount: amount,
                    fee: calculatedFee,
                    total: totalAmountWithFee,
                    currency: defaultCurrency,
                    accountName: accountName,
                    accountNumber: selectedAccount?.accountNumber ?? "",
                    bankName: selectedAccount?.bankName ?? "",
                    paymentDetails: paymentDetails,
                    isPresented: $showConfirmationDialog,
                    onConfirm: { pinCode in
                        showConfirmationDialog = false
                        processTransfer(with: pinCode)
                    },
                    onCancel: {
                        showConfirmationDialog = false
                    }
                )
            }
        }
    }
    

    // MARK: - Title Card
    private var titleCard: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.blueH)
                .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
            
            VStack(spacing: 8) {
                Text("Transfert vers Compte Bancaire")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.white)
                
                Rectangle()
                    .fill(.white)
                    .frame(width: 80, height: 3)
            }
            .padding(.vertical, 16)
        }
    }
    private var headerSection1: some View {
        HStack(spacing: 12) {
            RoundedRectangle(cornerRadius: 8)
                .fill(Color(red: 0.85, green: 0.92, blue: 1.0))
                .frame(width: 32, height: 32)
                .overlay(
                    Image(systemName: "creditcard.fill")
                        .font(.system(size: 18))
                        .foregroundColor(Color.blueH)
                )
            
            Text("Source des Fonds")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.2))
            
            Spacer()
        }
        .padding(.bottom, 20)
    }
    
    // MARK: - Balance Card
    private var balanceCard: some View {
        VStack(spacing: 10) {
            headerSection1
            Button(action: {
                
            }) {
                Text("Mon Portefeuille")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(.vertical, 10)
            }
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.greenH)
                    .shadow(color: Color(red: 0.2, green: 0.7, blue: 0.4).opacity(0.3), radius: 3)
            )
            
            ZStack {
                LinearGradient(
                    gradient: Gradient(colors: [
                        Color.blueH,
                        Color.blueH
                    ]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                
                VStack(spacing: 6) {
                    // Format balance with thousand separators
                    Text(currentBalance.isEmpty ? "GNF 0.00" : "\(currentBalance.formatAsCurrency()) GNF")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(.white)
                    
                    Text("Solde disponible")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(.white.opacity(0.8))
                    
                    Rectangle()
                        .fill(.white.opacity(0.6))
                        .frame(width: 40, height: 2)
                        .padding(.top, 8)
                }
                .padding(24)
            }
            .frame(height: 110)
            .cornerRadius(16)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 17)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
    // MARK: - Recipient Details Card
    private var recipientDetailsCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            // Header
            VStack(alignment: .leading, spacing: 4) {
                Text("Détails du compte bancaire")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color.greenH)
                
                Rectangle()
                    .fill(Color.blueH)
                    .frame(width: 60, height: 2)
            }
            
            // Account picker
            Menu {
                ForEach(linkedAccounts) { account in
                    Button(action: {
                        selectedAccount = account
                        verifyAccount(account)
                    }) {
                        Text(account.displayName)
                    }
                }
            } label: {
                HStack {
                    Text(selectedAccount?.displayName ?? "Sélectionner un compte")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(Color(red: 0.2, green: 0.2, blue: 0.2))
                    
                    Spacer()
                    
                    Image(systemName: "chevron.down")
                        .font(.system(size: 12))
                        .foregroundColor(Color(red: 0.6, green: 0.6, blue: 0.6))
                }
                .padding(.horizontal, 12)
                .frame(height: 48)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(red: 0.96, green: 0.96, blue: 0.96))
                )
            }
            .disabled(isLoadingAccounts || linkedAccounts.isEmpty)
            
            // Account name display
            TextField("Nom du destinataire", text: .constant(accountName))
                .font(.system(size: 12, weight: .medium))
                .padding(.horizontal, 12)
                .frame(height: 48)
                .background(Color(red: 0.96, green: 0.96, blue: 0.96))
                .cornerRadius(8)
                .disabled(true)
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
    // MARK: - Amount Card
    private var amountCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Montant")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color.greenH)
                
                Rectangle()
                    .fill(Color.blueH)
                    .frame(width: 60, height: 2)
            }
            
            // Replace the TextField with FormattedTextField
            FormattedTextField(
                placeholder: "Entrer le montant (GNF)",
                text: $amount
            )
                .onChange(of: amount) {
                    NSObject.cancelPreviousPerformRequests(withTarget: self)
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        self.calculateWithdrawalFee()
                    }
                }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
    
    
    private func calculateWithdrawalFeeDebounced() {
        calculateWithdrawalFee()
    }
    
    private func calculateWithdrawalFee() {
        let cleanAmount = amount.cleanCurrencyValue()
        
        guard !cleanAmount.isEmpty,
              let amountValue = Double(cleanAmount),
              amountValue > 0 else {
            withdrawalFee = 0.0
            withdrawalFeeError = nil
            isWithdrawalFeeEnabled = false
            return
        }
        
        isCalculatingWithdrawalFee = true
        withdrawalFeeError = nil
        
        var request = FeeCalculationRequest()
        request.processingCode = "42"
        request.bankCode = "00100"
        request.actionCode = "DEB"
        request.currencyCode = "324"
        request.transactionAmount = amountValue
        request.walletProductCode = "001"
        request.walletType = "P"
        request.origin = "W"
        request.messageType = "ON_US"
        
        APIClient.shared.calculateWithdrawalFee(request: request) { result in
            DispatchQueue.main.async {
                self.isCalculatingWithdrawalFee = false
                
                switch result {
                case .success(let response):
                    print("response: \(response)")
                    print("response: \(response.self)")
                    print("response: \(response.message)")
                    print("response: \(response.respCode)")

                    if response.respCode == "000" || response.respCode == "001" {
                        self.withdrawalFee = response.feeAmount ?? 0.0
                        if self.withdrawalFee == 0 {
                            self.isWithdrawalFeeEnabled = false
                        }
                    } else {
                        self.withdrawalFee = 0.0
                        self.isWithdrawalFeeEnabled = false
                        self.withdrawalFeeError = response.message
                    }
                    
                case .failure(_):
                    self.withdrawalFee = 0.0
                    self.isWithdrawalFeeEnabled = false
                    self.withdrawalFeeError = "Impossible de calculer"
                }
            }
        }
    }
    
    // MARK: - Reference Card
    private var referenceCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Commentaire (optionnel)")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(Color.greenH)
                
                Rectangle()
                    .fill(Color.blueH)
                    .frame(width: 60, height: 2)
            }
            
            TextField("Entrer un commentaire", text: $paymentDetails)
                .font(.system(size: 12, weight: .medium))
                .padding(.horizontal, 12)
                .frame(height: 48)
                .background(Color(red: 0.96, green: 0.96, blue: 0.96))
                .cornerRadius(8)
                .onReceive(paymentDetails.publisher.collect()) { chars in
                    if chars.count > 25 {
                        paymentDetails = String(chars.prefix(25))
                    }
                }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
    }
    
    // MARK: - Submit Button
    private var submitButton: some View {
        VStack(spacing: 16) {
            Button(action: {
                validateAndShowConfirmation()
            }) {
                Text("Soumettre")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: 150, height: 48)
                    .background(Color.greenH)
                    .cornerRadius(8)
            }
            .disabled(isLoading)
        }
        .padding(16)
    }
    
    private func fetchWalletBalance() {
        let formattedBalance = userDataManager.getFormattedBalance()
        
        if !formattedBalance.isEmpty {
            // Remove "GNF" prefix and extract just the number
            let cleanBalance = formattedBalance.replacingOccurrences(of: "GNF", with: "")
                                              .trimmingCharacters(in: .whitespaces)
            currentBalance = cleanBalance
        } else {
            currentBalance = "0.00"
        }
    }
    private func fetchLinkedAccounts() {
        isLoadingAccounts = true
        
        var request = RequestListLinkedAcc()
        request.source = "W"
        request.walletNumber = userDataManager.getWalletNumber()
        request.phoneNumber = userDataManager.getPhoneNumber()
        
        // Generate requestId
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyMMdd"
        let datePrefix = dateFormatter.string(from: Date())
        let randomDigits = String(format: "%06d", Int.random(in: 0...999999))
        request.requestId = datePrefix + randomDigits
        
        let fullDateFormatter = DateFormatter()
        fullDateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        request.requestDate = fullDateFormatter.string(from: Date())
        
        request.bank = userDataManager.getBankCode().isEmpty ? "00100" : userDataManager.getBankCode()
        request.entityId = UserDataManager.shared.getUserCode()
        
        APIClient.shared.getLinkedAccounts(request: request) { result in
            DispatchQueue.main.async {
                self.isLoadingAccounts = false
                
                switch result {
                case .success(let response):
                    if response.respCode == "000" || response.respCode == "00" {
                        self.parseLinkedAccounts(response)
                    } else {
                        self.showErrorAlert("Erreur: \(response.message ?? "Impossible de récupérer les comptes")")
                    }
                case .failure(let error):
                    if let apiError = error as? APIError {
                        self.showErrorAlert("Erreur: \(apiError.message)")
                    } else {
                        self.showErrorAlert("Erreur réseau: \(error.localizedDescription)")
                    }
                }
            }
        }
    }
    
    private func parseLinkedAccounts(_ response: JResponseService) {
        linkedAccounts.removeAll()
        
        if let resultList = response.result {
            for accountData in resultList {
                guard let dict = accountData as? [String: Any] else { continue }
                
                var account = Account()
                account.accountNumber = dict["accountNumber"] as? String ?? ""
                account.accountHolder = dict["accountHolder"] as? String ?? ""
                account.bankCode = dict["bankCode"] as? String ?? ""
                account.bankName = dict["bankName"] as? String ?? ""
                account.accountType = dict["accountType"] as? String ?? ""
                account.currency = dict["currency"] as? String ?? ""
                account.balance = dict["balance"] as? String ?? ""
                
                if !account.accountNumber.isEmpty {
                    linkedAccounts.append(account)
                }
            }
        }
        
        if linkedAccounts.isEmpty {
            showErrorAlert("Aucun compte bancaire lié trouvé")
        }
    }
    
    private func verifyAccount(_ account: Account) {
        guard !account.accountNumber.isEmpty else {
            showErrorAlert("Numéro de compte invalide")
            return
        }
        
        isVerifying = true
        accountName = ""
        
        var request = RequestWalletToBankAccountNE()
        request.walletNumber = userDataManager.getWalletNumber()
        request.source = "W"
        request.desBank = account.bankCode.isEmpty ? "00100" : account.bankCode
        request.srcBank = "00100"
        request.desAccount = account.accountNumber
        
        // Generate requestId
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyMMdd"
        let datePrefix = dateFormatter.string(from: Date())
        let randomDigits = String(format: "%06d", Int.random(in: 0...999999))
        request.requestId = datePrefix + randomDigits
        
        let fullDateFormatter = DateFormatter()
        fullDateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        request.requestDate = fullDateFormatter.string(from: Date())
        request.entityId = UserDataManager.shared.getUserCode()
        
        APIClient.shared.transferWalletToAccountNE(request: request) { result in
            DispatchQueue.main.async {
                self.isVerifying = false
                
                switch result {
                case .success(let response):
                    if response.respCode == "000" || response.respCode == "00" {
                        self.handleVerificationSuccess(response, account: account)
                    } else {
                        self.handleVerificationError(response)
                    }
                case .failure(let error):
                    if let apiError = error as? APIError {
                        self.showErrorAlert("Erreur: \(apiError.message)")
                    } else {
                        self.showErrorAlert("Erreur réseau: \(error.localizedDescription)")
                    }
                    self.accountName = ""
                }
            }
        }
    }
    
    private func handleVerificationSuccess(_ response: ResponseServiceJson, account: Account) {
        if let result = response.result {
            if let nameToCredit = result["NameToCredit"] as? String {
                accountName = nameToCredit
                nameEnquiryAuthCode = response.authCode ?? ""
                showSuccessAlert("Compte vérifié avec succès")
            } else {
                accountName = account.accountHolder.isEmpty ? account.accountName : account.accountHolder
                nameEnquiryAuthCode = response.authCode ?? ""
                showSuccessAlert("Compte vérifié")
            }
        } else {
            showErrorAlert("Information du compte non disponible")
            accountName = ""
        }
    }
    
    private func handleVerificationError(_ response: ResponseServiceJson) {
        let errorMessage = response.message ?? {
            switch response.respCode {
            case "001": return "Compte non trouvé"
            case "003": return "Données manquantes dans la requête"
            default: return "Échec de la vérification. Code: \(response.respCode ?? "N/A")"
            }
        }()
        
        showErrorAlert(errorMessage)
        accountName = ""
    }
    
    private func validateAndShowConfirmation() {
        guard validateInputs() else { return }
        calculateTransactionFee()
    }
    
    private func validateInputs() -> Bool {
        if selectedAccount == nil {
            showErrorAlert("Veuillez sélectionner un compte")
            return false
        }
        
        if amount.isEmpty {
            showErrorAlert("Le montant est requis")
            return false
        }
        
        if accountName.isEmpty {
            showErrorAlert("Veuillez d'abord vérifier le compte")
            return false
        }
        
        return true
    }
    
    private func calculateTransactionFee() {
        isLoading = true
        
        var feeRequest = FeeCalculationRequest()
        feeRequest.processingCode = "42" // Wallet to Account
        feeRequest.bankCode = selectedAccount?.bankCode ?? "00100"
        feeRequest.actionCode = "DEB"
        feeRequest.currencyCode = "324"
        feeRequest.transactionAmount = Double(amount.cleanCurrencyValue().replacingOccurrences(of: ",", with: ".")) ?? 0.0
        feeRequest.walletProductCode = "001"
        feeRequest.walletType = "P"
        feeRequest.origin = "W"
        
        APIClient.shared.calculateTransactionFee(request: feeRequest) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                
                switch result {
                case .success(let response):
                    if response.respCode == "000" {
                        self.calculatedFee = response.feeAmount ?? 0.0
                        self.totalAmountWithFee = (Double(self.amount.cleanCurrencyValue().replacingOccurrences(of: ",", with: ".")) ?? 0.0) + self.calculatedFee
                        self.feeRuleIndex = response.ruleIndex ?? ""
                    } else {
                        self.calculatedFee = 0.0
                        self.totalAmountWithFee = Double(self.amount.replacingOccurrences(of: ",", with: ".")) ?? 0.0
                    }
                case .failure(_):
                    self.calculatedFee = 0.0
                    self.totalAmountWithFee = Double(self.amount.replacingOccurrences(of: ",", with: ".")) ?? 0.0
                }
                
                self.showConfirmationDialog = true
            }
        }
    }
    
    private func processTransfer(with pinCode: String) {
        isLoading = true
        
        var request = RequestWalletToAccount()
        request.walletNumber = userDataManager.getWalletNumber()
        request.phoneNumber = userDataManager.getPhoneNumber()
        request.source = "W"
        request.srcBank = "00100"
        request.desAccount = selectedAccount?.accountNumber ?? ""
        request.desBank = selectedAccount?.bankCode ?? "00100"
        let baseAmount = Double(amount.cleanCurrencyValue()) ?? 0.0
        let withdrawalFeeValue = isWithdrawalFeeEnabled ? withdrawalFee : 0.0
        let finalAmount = baseAmount + withdrawalFeeValue
        request.amount = String(finalAmount)
        request.currency = numericCurrency
        request.reason = String(paymentDetails.prefix(25))
        request.pin = pinCode
        request.authCode = nameEnquiryAuthCode
        
        // Generate request ID
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyMMdd"
        let datePrefix = dateFormatter.string(from: Date())
        let randomDigits = String(format: "%06d", Int.random(in: 0...999999))
        let requestId = String((datePrefix + randomDigits).prefix(12))
        request.requestId = requestId
        
        let fullDateFormatter = DateFormatter()
        fullDateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        request.requestDate = fullDateFormatter.string(from: Date())
        request.entityId = UserDataManager.shared.getUserCode()
        
        APIClient.shared.transferWalletToAccount(request: request) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                
                switch result {
                case .success(let response):
                    if response.respCode == "000" {
                        self.handleTransferSuccess(response, requestId: requestId)
                    }else {
                        self.showError(message: "Transfert échoué: \(response.message ?? "Erreur inconnue")")
                    }
                case .failure(let error):
                    if let apiError = error as? APIError {
                        self.showErrorAlert("Erreur: \(apiError.message)")
                    } else {
                        self.showErrorAlert("Erreur réseau: \(error.localizedDescription)")
                    }
                }
            }
        }
    }
    
    private func handleTransferSuccess(_ response: ResponseServiceJson, requestId: String) {
        if let result = response.result {
            transactionId = result["transactionId"] as? String ?? 
                           result["reference"] as? String ?? 
                           requestId
        } else {
            transactionId = requestId
        }
        
        transactionReference = transactionId
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy HH:mm:ss"
        transactionDate = dateFormatter.string(from: Date())
        
        showSuccessDialog = true
    }
    private func showError(message: String) {
        alertTitle = "Erreur"
        alertMessage = message
        showAlert = true
    }
    private func showErrorAlert(_ message: String) {
        alertTitle = "Erreur"
        alertMessage = message
        showAlert = true
    }
    
    private func showSuccessAlert(_ message: String) {
        alertTitle = "Succès"
        alertMessage = message
        showAlert = true
    }
}

