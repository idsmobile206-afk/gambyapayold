//
//  DiamaPayHomeView.swift (Optimized)
//  DiamaPay
//

import SwiftUI

struct DiamaPayHomeView: View {
    @EnvironmentObject var authManager: AuthenticationManager
    @StateObject private var viewModel = HomeViewModel()
    @State private var showDrawer = false
    @State private var isFloatingMenuExpanded = false
    
    var body: some View {
            ZStack {
                mainContent
                overlays
                sideMenu
                floatingActionButton
                adPopup
                navigationLinks
            }
            .navigationBarHidden(true)
        }
       
    private var mainContent: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                HeaderSection(
                    userName: viewModel.userName,
                    balance: viewModel.balance,
                    currency: viewModel.currency,
                    isBalanceVisible: $viewModel.isBalanceVisible,
                    onMenuTap: { withAnimation { showDrawer.toggle() } },
                    onTransactionsTap: { viewModel.navigate(to: .transactions) }
                )
                
                VStack(spacing: 24) {
                    TransfersSection(onTransferTap: viewModel.navigate)
                    PromotionsSection(
                        ads: viewModel.ads,
                        onAdTap: viewModel.selectAd
                    )
                }
                .padding(.top, 28)
            }
        }
        .onAppear(perform: viewModel.onAppear)
        .disabled(showDrawer || isFloatingMenuExpanded || viewModel.showAdPopup)
        .blur(radius: blurRadius)
        .refreshable { await viewModel.refreshBalance() }
    }
    
    private var blurRadius: CGFloat {
        if showDrawer { return 5 }
        if isFloatingMenuExpanded { return 3 }
        if viewModel.showAdPopup { return 5 }
        return 0
    }
    
    // MARK: - Overlays
    private var overlays: some View {
        Group {
            if showDrawer || isFloatingMenuExpanded {
                Color.black.opacity(showDrawer ? 0.3 : 0.2)
                    .ignoresSafeArea()
                    .onTapGesture {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                            showDrawer = false
                            isFloatingMenuExpanded = false
                        }
                    }
            }
        }
    }
    
    // MARK: - Side Menu
    private var sideMenu: some View {
        HStack(spacing: 0) {
            if showDrawer {
                SideMenuView { selected in
                    viewModel.handleMenuSelection(selected, authManager: authManager)
                    withAnimation { showDrawer = false }
                }
                .frame(width: 300)
                .transition(.move(edge: .leading))
            }
            Spacer()
        }
    }
    
    // MARK: - Floating Action Button
    private var floatingActionButton: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                FloatingActionMenu(
                    isExpanded: $isFloatingMenuExpanded,
                    onAction: viewModel.handleFloatingAction
                )
                .padding(.trailing, 20)
                .padding(.bottom, 30)
            }
        }
        .zIndex(1)
    }
    
    // MARK: - Ad Popup
    private var adPopup: some View {
        Group {
            if viewModel.showAdPopup, let ad = viewModel.selectedAd {
                AdPopupView(ad: ad, isPresented: $viewModel.showAdPopup) {
                    viewModel.markAdAsViewed(ad)
                }
                .zIndex(100)
                .transition(.opacity.combined(with: .scale(scale: 0.9)))
            }
        }
    }
    
    // MARK: - Navigation Links
    private var navigationLinks: some View {
        Group {
            NavigationLink("", destination: WalletTransferView(), isActive: $viewModel.navigateToWalletTransfer)
            NavigationLink("", destination: WalletToAccountTransferView(), isActive: $viewModel.navigateToWalletToAccountTransfer)
            NavigationLink("", destination: TransactionHistoryView(), isActive: $viewModel.navigateToTransactions)
            NavigationLink("", destination: AccountToWalletTransferView(), isActive: $viewModel.navigateToAccountToWalletTransfer)
            NavigationLink("", destination: MoneyVoucherView(), isActive: $viewModel.navigateToMoneyVoucher)
            NavigationLink("", destination: LinkedAccountsListView(), isActive: $viewModel.navigateToLinkedAccounts)
            NavigationLink("", destination: StandingInstructionListView(), isActive: $viewModel.navigateToSI)
            NavigationLink("", destination: SponsoredWalletsListView(), isActive: $viewModel.navigateToSponsored)
            NavigationLink("", destination: SponsoringWalletListView(), isActive: $viewModel.navigateToSponsoring)
            NavigationLink("", destination: SponsorWalletView(), isActive: $viewModel.navigateToSponsor)
            NavigationLink("", destination: FAQView(), isActive: $viewModel.navigateToFAQ)
            NavigationLink("", destination: ChangePinView(), isActive: $viewModel.navigateToPin)
            NavigationLink("", destination: PendingTransactionsView(), isActive: $viewModel.navigateToPending)
            NavigationLink("", destination: MiniStatementView(), isActive: $viewModel.navigateToStatement)
            NavigationLink("", destination: SendCommentsView(), isActive: $viewModel.navigateToComment)
            NavigationLink("", destination: FileComplaintView(), isActive: $viewModel.navigateToComplaint)
            NavigationLink("", destination: QRPaymentView(), isActive: $viewModel.navigateToQR)
            NavigationLink("", destination: WalletDeactivationView(), isActive: $viewModel.navigateToDeactivate)
            NavigationLink("", destination: BiometricSettingsView(), isActive: $viewModel.navigateToBiometric)
            NavigationLink("", destination: CheckLimitView(), isActive: $viewModel.navigateToLimits)
            NavigationLink("", destination: TermsAndConditionsView(), isActive: $viewModel.navigateToTerms)
            NavigationLink("", destination: BillPayProvidersView(), isActive: $viewModel.navigateToBills)

        }
    }
}

// MARK: - View Model
@MainActor
class HomeViewModel: ObservableObject {
    @Published var userName = ""
    @Published var balance = "000.00"
    @Published var currency = "GNF"
    @Published var isBalanceVisible = false
    @Published var ads: [Advertisement] = []
    @Published var showAdPopup = false
    @Published var selectedAd: Advertisement?
    
    // Navigation states
    @Published var navigateToWalletTransfer = false
    @Published var navigateToWalletToAccountTransfer = false
    @Published var navigateToAccountToWalletTransfer = false
    @Published var navigateToTransactions = false
    @Published var navigateToMoneyVoucher = false
    @Published var navigateToLinkedAccounts = false
    @Published var navigateToSI = false
    @Published var navigateToSponsored = false
    @Published var navigateToSponsoring = false
    @Published var navigateToSponsor = false
    @Published var navigateToFAQ = false
    @Published var navigateToPin = false
    @Published var navigateToPending = false
    @Published var navigateToStatement = false
    @Published var navigateToComment = false
    @Published var navigateToComplaint = false
    @Published var navigateToQR = false
    @Published var navigateToDeactivate = false
    @Published var navigateToBiometric = false
    @Published var navigateToLimits = false
    @Published var navigateToTerms = false
    @Published var navigateToBills = false

    
    private var hasShownAdThisSession = false
    
    func onAppear() {
        userName = UserDataManager.shared.getUserName()
        ads = UserDataManager.shared.loadAdvertisements()
        Task {
            await fetchWalletBalance()
            showLatestAdIfNew()
        }
    }
    
    func refreshBalance() async {
        await fetchWalletBalance()
    }
    
    func selectAd(_ ad: Advertisement) {
        selectedAd = ad
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
            showAdPopup = true
        }
    }
    
    func navigate(to destination: NavigationDestination) {
        switch destination {
        case .walletTransfer: navigateToWalletTransfer = true
        case .walletToAccountTransfer: navigateToWalletToAccountTransfer = true
        case .accountToWalletTransfer: navigateToAccountToWalletTransfer = true
        case .transactions: navigateToTransactions = true
        case .qr: navigateToQR = true
        case .moneyVoucher: navigateToMoneyVoucher = true
        case .si: navigateToSI = true
        case .limits: navigateToLimits = true
        }
    }
    
    func handleMenuSelection(_ selected: String, authManager: AuthenticationManager) {
        switch selected {
        case "walletTransfer": navigateToWalletTransfer = true
        case "limits": navigateToLimits = true
        case "walletToAccountTransfer": navigateToWalletToAccountTransfer = true
        case "accountToWalletTransfer": navigateToAccountToWalletTransfer = true
        case "moneyVoucher": navigateToMoneyVoucher = true
        case "sponsored": navigateToSponsored = true
        case "terms": navigateToTerms = true
        case "qr": navigateToQR = true
        case "sponsoring": navigateToSponsoring = true
        case "linked": navigateToLinkedAccounts = true
        case "si": navigateToSI = true
        case "pinChange": navigateToPin = true
        case "pending": navigateToPending = true
        case "statement": navigateToStatement = true
        case "comment": navigateToComment = true
        case "complaint": navigateToComplaint = true
        case "deactivate": navigateToDeactivate = true
        case "biometric": navigateToBiometric = true
        case "FAQ": navigateToFAQ = true
        case "billPayment": navigateToBills = true

        case "logout":
            authManager.logout()
        default:
            break
        }
    }
    
    func handleFloatingAction(_ action: String) {
        switch action {
        case "moneyVoucher": navigateToMoneyVoucher = true
        case "sponsoring": navigateToSponsoring = true
        case "sponsor": navigateToSponsor = true
        case "sponsors": navigateToSponsoring = true
        case "si": navigateToSI = true
        case "payment": navigateToTransactions = true
        case "limits": navigateToLimits = true
        default:
            break
        }
    }
    
    func markAdAsViewed(_ ad: Advertisement) {
        guard let index = ads.firstIndex(where: { $0.id == ad.id }) else { return }
        ads[index].viewed = true
        UserDataManager.shared.markAdvertisementAsViewed(adId: ad.id)
    }
    
    private func showLatestAdIfNew() {
        guard !hasShownAdThisSession,
              let latestUnviewedAd = ads.first(where: { $0.viewed != true }) else {
            return
        }
        
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 500_000_000)
            selectedAd = latestUnviewedAd
            hasShownAdThisSession = true
            withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                showAdPopup = true
            }
        }
    }
    
    private func fetchWalletBalance() async {
        let walletNumber = UserDataManager.shared.getWalletNumber()
        let pin = UserDataManager.shared.getPinForAPI()
        
        guard !walletNumber.isEmpty else { return }
        
        let datePrefix = DateFormatter.with(format: "yyMMdd").string(from: Date())
        let randomDigits = String(format: "%06d", Int.random(in: 0..<1000000))
        let requestId = datePrefix + randomDigits
        let requestDate = DateFormatter.with(format: "yyyy-MM-dd HH:mm:ss").string(from: Date())
        
        let request = RequestBalanceEnquiry(
            walletNumber: walletNumber,
            phoneNumber: UserDataManager.shared.getPhoneNumber(),
            source: "W",
            pin: pin,
            bank: UserDataManager.shared.getBankCode(),
            requestId: requestId,
            requestDate: requestDate,
            entityId: UserDataManager.shared.getUserCode()
        )
        
        await withCheckedContinuation { continuation in
            APIClient.shared.getWalletBalance(request: request) { result in
                switch result {
                case .success(let response):
                    guard response.isSuccessful, let resultObj = response.result else {
                        continuation.resume()
                        return
                    }
                    
                    let availableAmount = Double(resultObj["availableBalance"] as? String ?? "0") ?? 0
                    let globalAmount = Double(resultObj["globalBalance"] as? String ?? "0") ?? 0
                    let currency = "GNF"
                    
                    UserDataManager.shared.saveWalletBalance(
                        availableAmount: availableAmount,
                        totalAmount: globalAmount,
                        currency: currency
                    )
                    
                    Task { @MainActor in
                        self.balance = availableAmount.formatAsCurrency()
                        self.currency = currency
                    }
                    
                case .failure(let error):
                    print("❌ Failed to load balance: \(error.localizedDescription)")
                }
                continuation.resume()
            }
        }
    }
}

// MARK: - Navigation Destination
enum NavigationDestination {
    case walletTransfer, walletToAccountTransfer, accountToWalletTransfer
    case transactions, qr, moneyVoucher, si, limits
}

// MARK: - Header Section
struct HeaderSection: View {
    let userName: String
    let balance: String
    let currency: String
    @Binding var isBalanceVisible: Bool
    let onMenuTap: () -> Void
    let onTransactionsTap: () -> Void
    
    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                Color.greenH
                    .ignoresSafeArea(edges: .top)
                
                VStack(spacing: 20) {
                    headerBar
                    userGreeting
                    BalanceCard(
                        balance: balance,
                        currency: currency,
                        isBalanceVisible: $isBalanceVisible,
                        onTransactionsTap: onTransactionsTap
                    )
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                }
            }
            .clipShape(RoundedRectangle(cornerRadius: 24))
        }
    }
    
    private var headerBar: some View {
        HStack {
            Button(action: onMenuTap) {
                Image(systemName: "line.horizontal.3")
                    .foregroundColor(.white)
                    .font(.title2)
            }
            Spacer()
            Text("DIAMACASH")
                .font(.title2)
                .fontWeight(.medium)
                .foregroundColor(.white)
            Spacer()
            Color.clear.frame(width: 24, height: 24)
        }
        .padding(.horizontal, 20)
        .padding(.top, 10)
    }
    
    private var userGreeting: some View {
        HStack {
            HStack(spacing: 16) {
                ZStack {
                    Circle()
                        .fill(Color.white.opacity(0.2))
                        .frame(width: 50, height: 50)
                    Image(systemName: "person.fill")
                        .foregroundColor(.white)
                        .font(.title3)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Bonjour,")
                        .font(.system(size: 14))
                        .foregroundColor(.white.opacity(0.9))
                    Text(userName)
                        .font(.system(size: 19, weight: .bold))
                        .foregroundColor(.white)
                }
            }
            Spacer()
        }
        .padding(.horizontal, 20)
    }
}

// MARK: - Balance Card
struct BalanceCard: View {
    let balance: String
    let currency: String
    @Binding var isBalanceVisible: Bool
    let onTransactionsTap: () -> Void
    
    var body: some View {
        VStack(spacing: 18) {
            HStack {
                Text("Solde Disponible")
                    .font(.system(size: 16, weight: .regular))
                    .foregroundColor(.primary)
                Spacer()
                Button(action: { isBalanceVisible.toggle() }) {
                    ZStack {
                        Circle()
                            .fill(.blueH)
                            .frame(width: 38, height: 38)
                        Image(systemName: isBalanceVisible ? "eye.fill" : "eye.slash.fill")
                            .foregroundColor(.white)
                            .font(.system(size: 16))
                    }
                }
            }
            
            HStack(spacing: 10) {
                Text(isBalanceVisible ? balance : "*********")
                    .font(.system(size: 25, weight: .semibold))
                    .foregroundColor(.greenH)
                Text(currency)
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(.greenH)
            }
            
            transactionsButton
        }
        .padding(24)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
    }
    
    private var transactionsButton: some View {
        HStack {
            ZStack {
                Circle()
                    .fill(Color.greenH.opacity(0.1))
                    .frame(width: 32, height: 32)
                Image(systemName: "clock.fill")
                    .foregroundColor(.greenH)
                    .font(.system(size: 14))
            }
            Text("Mes transactions")
                .font(.system(size: 12, weight: .medium))
                .foregroundColor(.primary)
            Spacer()
            Button(action: onTransactionsTap) {
                HStack(spacing: 4) {
                    Text("Voir plus")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.blueH)
                    Image(systemName: "chevron.right")
                        .foregroundColor(.blueH)
                        .font(.system(size: 12))
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 5)
        .background(Color.blueH.opacity(0.1))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.blueH, lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 24))
    }
}

// MARK: - Transfers Section
struct TransfersSection: View {
    let onTransferTap: (NavigationDestination) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionHeader
            transferCards
        }
    }
    
    private var sectionHeader: some View {
        HStack {
            Rectangle()
                .fill(LinearGradient(
                    colors: [Color(hex: "4CAF50"), Color.blueH],
                    startPoint: .top,
                    endPoint: .bottom
                ))
                .frame(width: 4, height: 22)
            Text("Transferts")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.primary)
            Spacer()
        }
        .padding(.horizontal, 20)
    }
    
    private var transferCards: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                TransferCard(
                    title: "Transfert d'argent",
                    icon: "arrow.left.arrow.right",
                    backgroundColor: Color.greenH.opacity(0.1),
                    iconColor: .greenH
                ) { onTransferTap(.walletTransfer) }
                
                TransferCard(
                    title: "Vers ma Banque",
                    icon: "arrow.left.arrow.right",
                    backgroundColor: Color.blueH.opacity(0.1),
                    iconColor: .blueH
                ) { onTransferTap(.walletToAccountTransfer) }
            }
            
            HStack(spacing: 12) {
                TransferCard(
                    title: "Recharger mon Wallet",
                    icon: "rectangle.fill.badge.plus",
                    backgroundColor: Color.blueH.opacity(0.1),
                    iconColor: .blueH
                ) { onTransferTap(.accountToWalletTransfer) }
                
                TransferCard(
                    title: "Paiement QR",
                    icon: "qrcode",
                    backgroundColor: Color.greenH.opacity(0.1),
                    iconColor: .greenH
                ) { onTransferTap(.qr) }
            }
        }
        .padding(20)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 20))
        .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
        .padding(.horizontal, 20)
    }
}

// MARK: - Transfer Card
struct TransferCard: View {
    let title: String
    let icon: String
    let backgroundColor: Color
    let iconColor: Color
    let action: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(backgroundColor)
                    .frame(width: 64, height: 64)
                Image(systemName: icon)
                    .frame(width: 20, height: 20)
                    .foregroundColor(iconColor)
            }
            
            Text(title)
                .font(.system(size: 13, weight: .regular))
                .foregroundColor(.primary)
                .multilineTextAlignment(.center)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
            
            Capsule()
                .fill(iconColor)
                .frame(width: 24, height: 3)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 16)
        .padding(.horizontal, 12)
        .background(RoundedRectangle(cornerRadius: 16).fill(iconColor.opacity(0.05)))
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(iconColor.opacity(0.3), lineWidth: 1.5))
        .onTapGesture(perform: action)
    }
}

// MARK: - Promotions Section
struct PromotionsSection: View {
    let ads: [Advertisement]
    let onAdTap: (Advertisement) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionHeader
            adScrollView
        }
    }
    
    private var sectionHeader: some View {
        HStack {
            Rectangle()
                .fill(LinearGradient(
                    colors: [Color(hex: "4CAF50"), Color.blueH],
                    startPoint: .top,
                    endPoint: .bottom
                ))
                .frame(width: 4, height: 22)
            Text("Promotions")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.primary)
            Spacer()
        }
        .padding(.horizontal, 20)
    }
    
    private var adScrollView: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(ads) { ad in
                    AdCard(ad: ad, onTap: { onAdTap(ad) })
                }
            }
            .padding(.horizontal, 15)
        }
    }
}

// MARK: - Ad Card
struct AdCard: View {
    let ad: Advertisement
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            ZStack(alignment: .topTrailing) {
                if let img = ad.decodedImage() {
                    img
                        .resizable()
                        .scaledToFill()
                        .frame(width: 280, height: 140)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                } else {
                    fallbackCard
                }
                
                if ad.viewed == true {
                    viewedBadge
                }
            }
        }
    }
    
    private var fallbackCard: some View {
        HStack {
            VStack(alignment: .leading, spacing: 8) {
                Text(ad.title ?? "Promo")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.white)
                Text(ad.description ?? "")
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.9))
                Spacer()
            }
            Spacer()
            Image(systemName: "megaphone.fill")
                .foregroundColor(.white.opacity(0.8))
                .font(.system(size: 40))
        }
        .padding(16)
        .frame(width: 280, height: 140)
        .background(Color(hex: "2E5E3E"))
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }
    
    private var viewedBadge: some View {
        HStack(spacing: 4) {
            Image(systemName: "eye.fill")
                .font(.system(size: 10))
            Text("Vu")
                .font(.system(size: 10, weight: .semibold))
        }
        .foregroundColor(.white)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(Color.black.opacity(0.6))
        .clipShape(Capsule())
        .padding(8)
    }
}

// MARK: - Floating Action Menu
struct FloatingActionMenu: View {
    @Binding var isExpanded: Bool
    let onAction: (String) -> Void
    
    private let menuItems: [(icon: String, label: String, color: Color, action: String)] = [
        ("clock.fill", "Historique des transactions", .gray, "payment"),
        ("person", "Sponsoriser un portefeuille", .cyan, "sponsor"),
        ("person.3.fill", "Mes parrains", .blueH, "sponsors"),
        ("ticket.fill", "Mise à disposition", .orange, "moneyVoucher"),
        ("arrow.left.arrow.right", "Virements permanents", .purple, "si"),
        ("gauge.with.needle.fill", "Mes limites", .green, "limits")
    ]
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            mainButton
            if isExpanded {
                menuItemsList
            }
        }
    }
    
    private var mainButton: some View {
        Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                isExpanded.toggle()
            }
        }) {
            ZStack {
                Circle()
                    .fill(Color.blueH)
                    .frame(width: 56, height: 56)
                    .shadow(color: .blueH.opacity(0.3), radius: 8, x: 0, y: 4)
                Image(systemName: "ellipsis")
                    .foregroundColor(.white)
                    .font(.title2)
                    .rotationEffect(.degrees(isExpanded ? 45 : 90))
            }
        }
    }
    
    private var menuItemsList: some View {
        VStack(spacing: 12) {
            ForEach(menuItems, id: \.action) { item in
                FloatingMenuItem(
                    icon: item.icon,
                    label: item.label,
                    backgroundColor: item.color
                ) {
                    onAction(item.action)
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                        isExpanded = false
                    }
                }
            }
        }
        .offset(y: -80)
        .transition(.asymmetric(
            insertion: .scale.combined(with: .opacity),
            removal: .scale.combined(with: .opacity)
        ))
    }
}

// MARK: - Floating Menu Item
struct FloatingMenuItem: View {
    let icon: String
    let label: String
    let backgroundColor: Color
    let action: () -> Void
    
    var body: some View {
        HStack(spacing: 12) {
            Spacer()
            Text(label)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color.black.opacity(0.7))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .shadow(color: .black.opacity(0.2), radius: 4, x: 0, y: 2)
            
            Button(action: action) {
                ZStack {
                    Circle()
                        .fill(backgroundColor)
                        .frame(width: 48, height: 48)
                        .shadow(color: backgroundColor.opacity(0.3), radius: 6, x: 0, y: 3)
                    Image(systemName: icon)
                        .foregroundColor(.white)
                        .font(.title3)
                }
            }
        }
    }
}

// MARK: - Ad Popup View
struct AdPopupView: View {
    let ad: Advertisement
    @Binding var isPresented: Bool
    var onClose: (() -> Void)?
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.6)
                .ignoresSafeArea()
                .onTapGesture { closePopup() }
            
            VStack(spacing: 0) {
                adHeader
                adContent
            }
            .frame(maxWidth: UIScreen.main.bounds.width - 40)
            .clipShape(RoundedRectangle(cornerRadius: 20))
            .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
        }
        .onAppear {
            if let onClose = onClose {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    onClose()
                }
            }
        }
    }
    
    private var adHeader: some View {
        ZStack(alignment: .topTrailing) {
            LinearGradient(
                colors: [Color(hex: "FF9F5A"), Color(hex: "FFA65C")],
                startPoint: .leading,
                endPoint: .trailing
            )
            
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(ad.description ?? "Promotion")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                    Text(ad.title ?? "Ne manquez pas cette opportunité")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.white.opacity(0.95))
                        .lineLimit(1)
                }
                Spacer()
            }
            .padding(.leading, 16)
            .padding(.trailing, 50)
            .padding(.vertical, 12)
            
            Button(action: closePopup) {
                ZStack {
                    Circle()
                        .fill(Color.white.opacity(0.3))
                        .frame(width: 36, height: 36)
                    Image(systemName: "xmark")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(.white)
                }
            }
            .padding(.top, 12)
            .padding(.trailing, 12)
        }
        .frame(maxWidth: .infinity)
        .fixedSize(horizontal: false, vertical: true)
    }
    
    private var adContent: some View {
        Group {
            if let image = ad.decodedImage() {
                image
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity)
                    .background(Color.white)
            } else {
                VStack(spacing: 20) {
                    Image(systemName: "megaphone.fill")
                        .font(.system(size: 60))
                        .foregroundColor(Color(hex: "4CAF50"))
                    Text("Aucune image disponible")
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .frame(height: 300)
                .background(Color.white)
            }
        }
    }
    
    private func closePopup() {
        withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
            isPresented = false
        }
    }
}

// MARK: - Extensions
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

extension DateFormatter {
    static func with(format: String) -> DateFormatter {
        let df = DateFormatter()
        df.locale = Locale(identifier: "en_US_POSIX")
        df.dateFormat = format
        return df
    }
}
