import SwiftUI


struct SideMenuView: View {
    var onSelect: (String) -> Void
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                HStack {
                    VStack(alignment: .leading) {
                        Text("DIAMACASH")
                            .font(.headline)
                            .foregroundColor(.white)
                            .bold()
                        Text("Votre portefeuille digital sécurisé")
                            .font(.caption)
                            .foregroundColor(.white)
                    }
                    .padding(.top, 50)
                    .padding()
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.greenH)
                
                Divider()
                
                Text("TRANSFERT")
                    .font(.caption)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                
                DrawerItem(icon: "arrow.left.arrow.right", title: "Transférer de l'argent") {
                    onSelect("walletTransfer")
                }
                DrawerItem(icon: "wallet.bifold.fill", title: "Wallet vers ma Banque") {
                    onSelect("walletToAccountTransfer")
                }
             
                DrawerItem(icon: "bankToWallet", title: "Banque vers mon Wallet") {
                    onSelect("accountToWalletTransfer")
                }
                DrawerItem(icon: "voucher", title: "Mise à disposition") {
                    onSelect("moneyVoucher")
                }
                DrawerItem(icon: "qrcode", title: "Paiement QR") {
                    onSelect("qr")
                }
                DrawerItem(icon: "arrow.left.arrow.right", title: "Virements Permanents") {
                    onSelect("si")
                }
                
                Divider()
                
                Text("RECHARGES")
                    .font(.caption)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                
                DrawerItem(icon: "bill", title: "Paiement des factures") {
                    onSelect("billPayment")
                }
                
                Divider()
                // Support group
                Text("PARRAINAGE")
                    .font(.caption)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                
                DrawerItem(icon: "sponsored", title: "Portefeuilles parrainés") {
                    onSelect("sponsored")
                }
                DrawerItem(icon: "sponsor", title: "Afficher mes parrains") {
                    onSelect("sponsoring")
                }
               
                
                Divider()
                Text("GESTION DU PORTEFEUILLE")
                    .font(.caption)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                
                DrawerItem(icon: "gauge.with.needle.fill", title: "Mes limites") {
                    onSelect("limits")
                }
                
                DrawerItem(icon: "savingsstatement", title: "Demande de mini-relevé") {
                    onSelect("statement")
                }
                
                DrawerItem(icon: "deactivate", title: "Désactiver mon compte") {
                    onSelect("deactivate")
                }
                
              
                DrawerItem(icon: "pending", title: "Transaction à valider") {
                    onSelect("pending")
                }
                DrawerItem(icon: "linked", title: "Comptes Bancaires") {
                    onSelect("linked")
                }
                Divider()
                Text("PARAMETRE")
                    .font(.caption)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                
                DrawerItem(icon: "pin", title: "Changer le code PIN") {
                    onSelect("pinChange")
                }
                DrawerItem(icon: "biometric", title: "Connexion biométrique") {
                    onSelect("biometric")
                }
                .overlay(
                    HStack {
                        Spacer()
                        if UserDataManager.shared.isBiometricEnabled() {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                                .font(.system(size: 16))
                                .padding(.trailing, 16)
                        }
                    }
                )
                Divider()
                Text("ASSISTANCE")
                    .font(.caption)
                    .padding(.horizontal, 20)
                    .padding(.vertical, 12)
                DrawerItem(icon: "bubble.left", title: "Écrire un commentaire") {
                    onSelect("comment")
                }
                DrawerItem(icon: "exclamationmark.bubble", title: "Déclarer un incident") {
                    onSelect("complaint")
                }
                
                DrawerItem(icon: "phone", title: "Contactez-nous") {
                    makePhoneCall(phoneNumber: "+224612008699")
                }
                
                DrawerItem(icon: "terms", title: "Conditions générales") {
                    onSelect("terms")
                }
                DrawerItem(icon: "faq", title: "FAQ") {
                    onSelect("FAQ")
                }
                
                DrawerItem(icon: "rectangle.portrait.and.arrow.right", title: "Déconnexion") {
                    onSelect("logout")
                }
                .foregroundColor(.red)
                
                Spacer()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white)
        }
    }
    
    private func makePhoneCall(phoneNumber: String) {
        let cleanedNumber = phoneNumber.replacingOccurrences(of: " ", with: "")
        
        guard let url = URL(string: "tel://\(cleanedNumber)") else {
            //print("Invalid phone number")
            return
        }
        
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url, options: [:]) { success in
                if success {
                    //print("Phone call initiated successfully")
                } else {
                    //print("Failed to initiate phone call")
                }
            }
        } else {
            //print("This device cannot make phone calls")
        }
    }
}

// MARK: - Preview
struct SideMenuView_Previews: PreviewProvider {
    static var previews: some View {
        SideMenuView { selection in
            //print("Selected: \(selection)")
        }
        .frame(width: 300)
        .previewLayout(.sizeThatFits)
    }
}
