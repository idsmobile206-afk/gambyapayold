//
//  DrawerItem.swift
//  DiamaPay
//
//  Created by Bits on 18/9/2025.
//

import SwiftUI

struct DrawerItem: View {
    var icon: String
    var title: String
    var onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack {
                // Handle biometric icon dynamically based on device
                if icon == "biometric" {
                    Image(systemName: BiometricHelper.getBiometricType().icon)
                        .frame(width: 20, height: 20)
                        .foregroundColor(Color(red: 0.1, green: 0.4, blue: 0.1))
                }
                // Try to load system icon first, otherwise fallback to asset
                else if UIImage(systemName: icon) != nil {
                    Image(systemName: icon)
                        .frame(width: 20, height: 20)
                        .foregroundColor(Color(red: 0.1, green: 0.4, blue: 0.1))
                } else {
                    Image(icon) // Loads from Assets
                        .resizable()
                        .scaledToFit()
                        .frame(width: 20, height: 20)
                        .foregroundColor(Color(red: 0.1, green: 0.4, blue: 0.1))
                }
                
                Text(title)
                    .font(.system(size: 12))
                    .foregroundColor(.black)
                    .padding(.leading, 8)
                
                Spacer()
                
                // Show checkmark if biometric is enabled
                if icon == "biometric" && UserDataManager.shared.isBiometricEnabled() {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.greenH)
                        .font(.system(size: 14))
                }
            }
            .padding(.vertical, 10)
            .padding(.horizontal, 20)
        }
    }
}
